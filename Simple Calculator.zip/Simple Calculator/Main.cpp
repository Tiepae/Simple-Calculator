#include <stdio.h>



int main()
{
	char op;
	float num1, num2;

	num1 = 0;
	num2 = 0;

	printf("Enter two numbers: ");
	if (scanf_s("%f %f", &num1, &num2) != 2) {
		puts("Invalid input. Please enter two valid numbers.\n");
		return 1;
	}
	getchar();
	printf("\nEnter an operator (+, -, *, /): ");
	scanf_s("%c", &op, 1);
	getchar();

	switch (op)
	{
	case '+':
		printf("Result is: %f", num1 + num2);
		break;
	case '-':
		printf("Result is: %f\n", num1 - num2);
		break;
	case '*':
		printf("Result is: %f\n", num1 * num2);
		break;
	case '/':
		if (num2 == 0) {
			printf("You cannot divide this number");
			break;
		}
		printf("Result is: %f\n", num1 / num2);
		break;
	default:
		printf("Invalid operator\n");
		break;
	}
	getchar();
	return 0;
}